import os

def edit_fingerprint(elf):
    new_elf = os.tmpfile()